import React from 'react';
import './App.css';
import Portfolio from './components/Portfolio';
import Team from './components/Team';
import Clients from './components/Clients';
import Contact from './components/Contact';
import About from './components/About';
import Services from './components/Services';
import Navbar from './components/Navbar';
import Header from './components/Header';
function App() {
    const portfolioLinks = [
        {
            title: 'Threads',
            caption: 'Illustration'
        },
        {
            title: 'Explore',
            caption: 'Graphic Design'
        },
        {
            title: 'Finish',
            caption: 'Identity'
        },
        {
            title: 'Lines One',
            caption: 'Branding'
        },
        {
            title: 'Lines Two',
            caption: 'Branding'
        },
        {
            title: 'Lines Three',
            caption: 'Branding'
        }
    ]
  return (

    <div className="App">
        <Navbar/>
        <Header/>
        <Services/>
        <Portfolio portfolioLinks={portfolioLinks}/>    
        <About/>
        <Team/>
        <Clients/>
        <Contact/>
        
        <footer className="footer py-4">
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-lg-4 text-lg-start">Copyright &copy; Your Website 2021</div>
                    <div className="col-lg-4 my-3 my-lg-0">
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-twitter"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-facebook-f"></i></a>
                        <a className="btn btn-dark btn-social mx-2" href="#!"><i className="fab fa-linkedin-in"></i></a>
                    </div>
                    <div className="col-lg-4 text-lg-end">
                        <a className="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                        <a className="link-dark text-decoration-none" href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>
  );
}

export default App;
