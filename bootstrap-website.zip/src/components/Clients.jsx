import React from 'react'
import clientImg1 from '../assets/img/logos/microsoft.svg';
import clientImg2 from '../assets/img/logos/google.svg';
import clientImg3 from '../assets/img/logos/facebook.svg';
import clientImg4 from '../assets/img/logos/ibm.svg';

function Clients() {
    return (
        <div className="py-5">
        <div className="container">
            <div className="row align-items-center">
                <div className="col-md-3 col-sm-6 my-3">
                    <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src={clientImg1} alt="..." /></a>
                </div>
                <div className="col-md-3 col-sm-6 my-3">
                    <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src={clientImg2} alt="..." /></a>
                </div>
                <div className="col-md-3 col-sm-6 my-3">
                    <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src={clientImg3} alt="..." /></a>
                </div>
                <div className="col-md-3 col-sm-6 my-3">
                    <a href="#!"><img className="img-fluid img-brand d-block mx-auto" src={clientImg4} alt="..." /></a>
                </div>
            </div>
        </div>
    </div>
    )
}

export default Clients
