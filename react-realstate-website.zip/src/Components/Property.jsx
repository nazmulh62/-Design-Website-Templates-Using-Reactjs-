import React from 'react';
import Bproperty from './Bproperty';
import pimage1 from '../images/p1.png';
import pimage2 from '../images/p2.png';
import pimage3 from '../images/p3.png';

function Property() {
    return (
        <div className='product'>
            <div className='p-heading'>
                <h3>Properties</h3>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever</p>
            </div>
            <div className='product-container'>
                <Bproperty image={pimage1} name="Kamal" price="$2500000" />
                <Bproperty image={pimage2} name="Rana" price="$3500000" />
                <Bproperty image={pimage3} name="Raju" price="$4500000" />

            </div>

        </div>
    )
}

export default Property
