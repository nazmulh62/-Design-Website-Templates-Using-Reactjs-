import React, {useState} from 'react';
import logo from '../images/logo1.png';
import {Link} from 'react-scroll';

function Navbar() {

  const [nav,setnav] = useState(false);

  const changeBackground = () => {
      if(window.scrollY >= 50){
        setnav(true);
      }
      else{
          setnav(false);
      }
  }

  window.addEventListener('scroll',changeBackground);
    return (
        <nav>
           <Link to='main' className='logo' smooth={true} duration={2000}>
             <img src={logo} alt='logo'/>
           </Link>
           <input className='menu-btn' type='checkbox' id='menu-btn'/>
           <label className='menu-icon' for='menu-btn'> 
                <span className='nav-icon'></span>
           </label>
           <ul className='menu'>
               <li><Link to='main' className='{nav ? "nav active" :"nav"}'>Home</Link></li>
               <li><Link to='about' smooth={true} duration={2000}>About</Link></li>
               <li><Link to='agent' smooth={true} duration={2000}>Agent</Link></li>
               <li><Link to='property' smooth={true} duration={2000}>Property</Link></li>
               <li><Link to='contact' smooth={true} duration={2000}>Contact</Link></li>
           </ul>
           <Link to='product' className='property' smooth={true} duration={2000}>Properties</Link>
        </nav>
    )
}

export default Navbar;
